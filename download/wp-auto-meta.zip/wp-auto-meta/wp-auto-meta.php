<?php
/**
 * @package WordpressAutoMeta
 * @author Pavel Vrubel
 * @version 0.2
 */
/*
Plugin Name: Wordpress Auto Meta
Plugin URI: http://web2s.ru/wam
Description: Wordpress meta tags auto-generator
Author: Pavel Vrubel
Version: 0.2
Author URI: http://web2s.ru
*/

define('WAM_FRONT_PAGE_KEYWORDS', 'wordpress, auto, meta, generator, wam');
define('WAM_NUM_KEYWORDS', 5);

add_option('wam_dir', WP_PLUGIN_DIR.'/'.str_replace(basename( __FILE__),'',plugin_basename(__FILE__)));
add_option('wam_url', WP_PLUGIN_URL.'/'.str_replace(basename( __FILE__),'',plugin_basename(__FILE__)));

if (!class_exists("WordpressAutoMeta")) {
class WordpressAutoMeta {
  var $optionsName = "WAMOptionsPage";
  function WordpressAutoMeta() {
    
  }
  function head() {
    global $post;
    $pc = get_post_custom($post->ID);
    echo '<meta name="keywords" content="';
    if (isset($pc['keywords'])&&$pc['keywords']) {
      echo $pc['keywords'][0];
    } else if (is_front_page()) {
      echo WAM_FRONT_PAGE_KEYWORDS;
    } else {
      echo $this->getKeywords($post->post_content, WAM_NUM_KEYWORDS);
    } 
    echo '" />'."\n";
    echo '<meta name="description" content="';
    if (isset($pc['description'])&&$pc['description']) {
      echo $pc['description'][0];
    } else if (is_front_page()) {
      bloginfo('description');
    } else {
      echo $post->post_title;
    }
    echo '" />'."\n";
  }
  
function getKeywords($content,$maxLength=5) {
  require_once get_option('wam_dir').'includes/utf8/utf8.php';
  $content = utf8_strtolower($content);
  $search = array ('@<script[^>]*?>.*?</script>@si', '@<[\/\!]*?[^<>]*?>@si', '@([\r\n])[\s]+@', '@&(quot|#34);@i', '@&(amp|#38);@i', '@&(lt|#60);@i', '@&(gt|#62);@i', '@&(nbsp|#160);@i', '@&(iexcl|#161);@i', '@&(cent|#162);@i', '@&(pound|#163);@i', '@&(copy|#169);@i', '@&#(\d+);@e'); 
  $replace = array (' ', ' ', '\1', '"', '&', '<', '>', ' ', chr(161), chr(162), chr(163), chr(169), 'chr(\1)'); 
  $content = preg_replace($search, $replace, $content);
  $content = str_replace("\r"," ",$content);
  $content = str_replace("\n"," ",$content);
  $content = preg_replace("/[^а-яёa-z\h]/u", "", $content);
  $content = preg_replace('/\h+/', ' ', trim($content));
  $content = preg_replace('/\v{3,}/', PHP_EOL.PHP_EOL, $content);
  $words = explode(' ',$content);
  $f = file_get_contents(get_option('wam_dir').'stopwords.txt');
  $stopwords = mb_split( '[ \n]+', mb_strtolower( $f, 'utf-8' ) );
  $words = array_diff($words, $stopwords);
  $count = array_count_values($words);
  arsort($count, SORT_NUMERIC);
  $keywords = array_keys($count);
  $keywords = array_slice($keywords, 0, $maxLength);
  return implode(', ',$keywords);
}
  
  function init() {
    $this->getOptions();
  }
  function loaded() {
  
  }
}
}

if (class_exists("WordpressAutoMeta")) {
	$wam = new WordpressAutoMeta();
}

//Actions and Filters	
if (isset($wam)) {
	//Actions
  add_action('plugins_loaded', array(&$wam, 'loaded'), 1);
  add_action('wp_head', array(&$wam, 'head'), 1);
}

register_activation_hook( __FILE__, 'wam_activate' );
function wam_activate() {

}
register_deactivation_hook( __FILE__, 'wam_deactivate' );
function wam_deactivate() {

}

?>