<?php
/**
 * @package WordpressImageEffects
 * @author Pavel Vrubel
 * @version 0.1
 */
/*
Plugin Name: Wordpress Image Effects
Plugin URI: http://web2s.ru/wie
Description: WIE allows you to add corners (and also shading and shadow) to images on your posts. Plugin based on js libs http://www.netzgesta.de/corner/ by Christian Effenberger.
Author: Pavel Vrubel
Version: 0.1
Author URI: http://web2s.ru
*/
/*
Thanks to:
Christian Effenberger http://www.netzgesta.de/corner/
S.C. Chen http://simplehtmldom.sourceforge.net/
Jan Odvárko http://jscolor.com/

Without these people, this plugin would not have become the reality it is…
*/

add_option('wie_dir', WP_PLUGIN_DIR.'/'.str_replace(basename( __FILE__),'',plugin_basename(__FILE__)));
add_option('wie_url', WP_PLUGIN_URL.'/'.str_replace(basename( __FILE__),'',plugin_basename(__FILE__)));

if (!class_exists("WordpressImageEffects")) {
class WordpressImageEffects {
  var $optionsName = "WIEOptionsPage";
  function WordpressImageEffects() {
    
  }
  function init() {
    $this->getOptions();
    //load_plugin_textdomain('wie', false, dirname(plugin_basename( __FILE__ )));
  }
  function loaded() {
  
  }
  function enabled() {
    $options = $this->getOptions();
    return $options['iradius'] || $options['iborder'] || $options['ishade'] || $options['ishadow'];
  }
  function enqueueScript() {
    $options = $this->getOptions();
    // Thanks to Christian Effenberger http://www.netzgesta.de/corner/
    if ($this->enabled()) wp_enqueue_script('justcorners', get_option('wie_url').'js/corner/'.$options['lib']); 
  }
  function content($content = '') {
    $options = $this->getOptions();
    if (!$this->enabled()) return $content;
    // Thanks to S.C. Chen http://simplehtmldom.sourceforge.net/
    require_once(get_option('wie_dir').'includes/simplehtmldom/simple_html_dom.php');
    $html = str_get_html($content);
    foreach($html->find('img') as $img) {
      if ($options['lib'] == 'justcorners.js') {
        $img->class .= isset($img->class) ? ' corners' :  'corners';
        if ($options['iradius']) {
          $img->class .= ' iradius'.$options['iradius'].' iradiae'.$options['iradiae-top-left'].$options['iradiae-top-right'].$options['iradiae-bottom-left'].$options['iradiae-bottom-right'];
        }
        if ($options['iborder']) {
          $img->class .= ' iborder'.$options['iborder'].' icolor'.$options['icolor'];
        }
      } else {
        $img->class .= isset($img->class) ? ' corner' :  'corner';
        if ($options['iradius']) {
          $img->class .= ' iradius'.$options['iradius'];
        }
        if ($options['ishade']) {
          $img->class .= ' ishade'.$options['ishade'];
        }
        if ($options['ishadow']) {
          $img->class .= ' ishadow'.$options['ishadow'];
        }
        if ($options['inverse']) {
          $img->class .= ' inverse';
        }
      }
    }
    $content = $html->outertext;
    $html->clear(); 
    unset($html);
    return $content;
  }
  function adminEnqueueScript() {
    // Thanks to Jan Odvárko http://jscolor.com/
    wp_enqueue_script('jscolor', get_option('wie_url').'js/jscolor/jscolor.js'); 
  }
  function getOptions() {
    $options = array('lib' => 'justcorners.js',
      'iradius' => 0,
      'iborder' => 0,
      'icolor' => '0000ff',
      'iradiae-top-left' => 1,
      'iradiae-top-right' => 1,
      'iradiae-bottom-left' => 1,
      'iradiae-bottom-right' => 1,
      'ishade' => 0,
      'ishadow' => 0,
      'inverse' => ''
    );
    $wieOptions = get_option($this->optionsName);
    if (!empty($wieOptions)) {
      foreach ($wieOptions as $key => $option) $options[$key] = $option;
    }				
    update_option($this->optionsName, $options);
    return $options;
  }
  function optionsPage() {
    $options = $this->getOptions();
    if (isset($_POST['Submit'])) { 
      if (isset($_POST['lib'])) {
        $options['lib'] = $_POST['lib'];
      }
      if (isset($_POST['iradius'])) {
        $options['iradius'] = $_POST['iradius'];
      }
      if (isset($_POST['iborder'])) {
        $options['iborder'] = $_POST['iborder'];
      }
      if (isset($_POST['icolor'])) {
        $options['icolor'] = $_POST['icolor'];
      }
      if (isset($_POST['iradiae-top-left'])) {
        $options['iradiae-top-left'] = $_POST['iradiae-top-left'];
      } else { $options['iradiae-top-left'] = 0;}
      if (isset($_POST['iradiae-top-right'])) {
        $options['iradiae-top-right'] = $_POST['iradiae-top-right'];
      } else { $options['iradiae-top-right'] = 0;}
      if (isset($_POST['iradiae-bottom-left'])) {
        $options['iradiae-bottom-left'] = $_POST['iradiae-bottom-left'];
      } else { $options['iradiae-bottom-left'] = 0;}
      if (isset($_POST['iradiae-bottom-right'])) {
        $options['iradiae-bottom-right'] = $_POST['iradiae-bottom-right'];
      } else { $options['iradiae-bottom-right'] = 0;}
      if (isset($_POST['ishade'])) {
        $options['ishade'] = $_POST['ishade'];
      }
      if (isset($_POST['ishadow'])) {
        $options['ishadow'] = $_POST['ishadow'];
      }
      if (isset($_POST['inverse'])) {
        $options['inverse'] = 'inverse';
      } else { $options['inverse'] = '';}
      update_option($this->optionsName, $options);
    ?>
<div id="message" class="updated fade"><p><strong><?php _e("Settings saved.", "WordpressImageEffects");?></strong></p></div>
    <?php
    }
    ?>
<div class=wrap>
<div id="icon-options-general" class="icon32"><br /></div>
<h2>Wordpress Image Effects Settings</h2>
<form method="post" action="<?php echo $_SERVER["REQUEST_URI"]; ?>">
<table class="form-table">
<tr valign="top">
<th scope="row"><?php _e('Effects library'); ?></th>
<td><label title="justcorners.js"><input type="radio" name="lib" value="justcorners.js" onclick="jQuery('.justcorners-js').show();jQuery('.corner-js').hide();" <?php echo $options['lib'] == 'justcorners.js'  ? 'checked="checked"' : '';?> /> justcorners.js</label> or <label title="corner.js"><input type="radio" name="lib" value="corner.js" onclick="jQuery('.justcorners-js').hide();jQuery('.corner-js').show();" <?php echo $options['lib'] != 'justcorners.js'  ? 'checked="checked"' : '';?> /> corner.js</label><br />
<span class="description">Corner selection and Borders or Image shading and shadow?</span></td>
</tr>
<tr valign="top">
<th scope="row"><label for="iradius">Corner radius</label></th>
<td><input name="iradius" type="text" id="iradius" value="<?php echo $options['iradius']; ?>" class="regular-text" />
<span class="description">min=0 max=100</span></td>
</tr>
<tr valign="top" class="justcorners-js<?php echo $options['lib'] != 'justcorners.js' ? ' hidden' : '';?>">
<th scope="row">Corner selection</th>
<td>
  <input type="checkbox" name="iradiae-top-left" id="iradiae-top-left" value="1" <?php echo $options['iradiae-top-left']  ? 'checked="checked"' : '';?> /><label for="iradiae-top-left">top left</label>
  <input type="checkbox" name="iradiae-top-right" id="iradiae-top-right" value="1" <?php echo $options['iradiae-top-right'] ? 'checked="checked"' : '';?> /><label for="iradiae-top-right">top right</label>
  <input type="checkbox" name="iradiae-bottom-left" id="iradiae-bottom-left" value="1" <?php echo $options['iradiae-bottom-left'] ? 'checked="checked"' : '';?> /><label for="iradiae-bottom-left">bottom left</label>
  <input type="checkbox" name="iradiae-bottom-right" id="iradiae-bottom-right" value="1" <?php echo $options['iradiae-bottom-right'] ? 'checked="checked"' : '';?> /><label for="iradiae-bottom-right">top right</label>
</td>
</tr>
<tr valign="top" class="justcorners-js<?php echo $options['lib'] != 'justcorners.js' ? ' hidden' : '';?>">
<th scope="row"><label for="iborder">Corner border</label></th>
<td><input name="iborder" type="text" id="iborder" value="<?php echo $options['iborder']; ?>" class="regular-text" />
<span class="description">min=0 max=100</span></td>
</tr>
<tr valign="top" class="justcorners-js<?php echo $options['lib'] != 'justcorners.js' ? ' hidden' : '';?>">
<th scope="row"><label for="icolor">Border color</label></th>
<td><input name="icolor" type="text" id="icolor" value="<?php echo $options['icolor']; ?>" class="regular-text color" />
<span class="description">min=000000 max=ffffff</span></td>
</tr>
<tr valign="top" class="corner-js<?php echo $options['lib'] != 'corner.js' ? ' hidden' : '';?>">
<th scope="row"><label for="ishade">Image shading</label></th>
<td><input name="ishade" type="text" id="ishade" value="<?php echo $options['ishade']; ?>" class="regular-text" />
<span class="description">min=0 max=100</span></td>
</tr>
<tr valign="top" class="corner-js<?php echo $options['lib'] != 'corner.js' ? ' hidden' : '';?>">
<th scope="row"><label for="ishadow">Image shadow</label></th>
<td><input name="ishadow" type="text" id="ishadow" value="<?php echo $options['ishadow']; ?>" class="regular-text" />
<span class="description">min=0 max=100</span></td>
</tr>
<tr valign="top" class="corner-js<?php echo $options['lib'] != 'corner.js' ? ' hidden' : '';?>">
<th scope="row">Shadow</th>
<td><input type="checkbox" name="inverse" id="inverse" value="inverse" <?php echo $options['inverse'] ? 'checked="checked"' : '';?> /><label for="inverse">invert</label></td>
</tr>
</table>
<p class="submit"><input type="submit" name="Submit" class="button-primary" value="<?php _e('Save Changes', 'WordpressImageEffects') ?>" /></p>
</form>
</div>
    <?php
  }
}
}

if (class_exists("WordpressImageEffects")) {
	$wie = new WordpressImageEffects();
}

if (!function_exists("wieOptionsPage")) {
	function wieOptionsPage() {
		global $wie;
		if (!isset($wie)) {
			return;
		}
		if (function_exists('add_options_page')) {
      add_options_page('Wordpress Image Effects', 'Wordpress Image Effects', 9, basename(__FILE__), array(&$wie, 'optionsPage'));
		}
	}	
}

//Actions and Filters	
if (isset($wie)) {
	//Actions
	add_action('admin_menu', 'wieOptionsPage');
  add_action('plugins_loaded', array(&$wie, 'loaded'), 1);
  add_action('wp_enqueue_scripts', array(&$wie, 'enqueueScript'), 1);
  add_action('admin_enqueue_scripts', array(&$wie, 'adminEnqueueScript'),1);
	//Filters
  add_filter('the_content', array(&$wie, 'content'),1); 
}

register_activation_hook( __FILE__, 'wie_activate' );
function wie_activate() {

}
register_deactivation_hook( __FILE__, 'wie_deactivate' );
function wie_deactivate() {

}

?>